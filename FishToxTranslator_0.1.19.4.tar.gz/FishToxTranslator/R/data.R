#~             ,''''''''''''''.
#~~           +     USEPA      +
#~   >~',*> <   FISH TOXICITY   }
#~~           +   TRANSLATOR   +
#~             `..............'
#~~
#~  N. Pollesch - pollesch.nathan@epa.gov
#

#' Data: Master Parameter List
#'
#' This includes the list and description of all parameters currently used in the Fish Toxicity Translator
#'
#' @name parameters_master
#' @keywords parameters_master
#' @docType data
"parameters_master"

#' Data: Species Library
#'
#' A reference for all species included in the model.  Common name, scientific name, and reference for species profile
#' data built into the R package
#'
#' @name species_library
#' @docType data
"species_library"

#' Data: Species Profile - Pimephales promelas
#'
#' Species profile data for given species
#'
#' @name pimephales_promelas
#' @docType data
"pimephales_promelas"

#' Data: Species Profile - Lepomis macrochirus
#'
#' Species profile data for given species
#'
#' @name lepomis_macrochirus
#' @docType data
"lepomis_macrochirus"
