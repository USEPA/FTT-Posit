# ### This file is created for troubleshooting visualize scenarios functions
# ## It creates two (or more) different species and adds them to the parameters list (without stressors)
# ##  to create multiple parameters for multiple species to test visualization functions for proper use
#
# library(FishToxTranslator)
# getwd()
# #setwd("C:/Users/npollesc/OneDrive - Environmental Protection Agency (EPA)/Profile/Documents/GitHub/FTT-R")
#
# #### Initialize lists, vectors, and data.frames
# # Create an empty vector to store scenario names
# scenarioNames<-vector()
# # Create an empty list to store scenario descriptions
# scenarioDescriptions<-list()
# # Create an empty list to store parameters indexed by scnarioNames
# parameters<-list()
#
#
# # Name the scenario
# # GUI: Submit baseline name as character string
# currentScenarioName<-"Baseline 1" # take input
# scenarioNames<-cbind(scenarioNames,currentScenarioName) # append new scenario name to list
#
# # GUI: Submit scenario description as character string likely as a textAreaInput
# currentScenarioDescription<-"Baseline 1 for testing"
# scenarioDescriptions[[currentScenarioName]]<-currentScenarioDescription
#
# # Define species
# # GUI: Can populate list choices from "species_library" object
# speciesChoices<-species_library$common_name # create list options
# # GUI: Choose species from list
# # If Known Species:
# chosenSpecies<-speciesChoices[1] # This chooses "Fathead Minnow" (the only choice as of 1/23/25)
# # Gather life history parameters for known species
# # Match chosen name to FishToxTranslator data() object associated with choice
# species_library$parameter_data[which(species_library$common_name==chosenSpecies)]
# chosenSpeciesDataObject<-as.character(species_library$parameter_data[which(species_library$common_name==chosenSpecies)])
# chosenLifeHistoryParameters<-get(chosenSpeciesDataObject)
#
# parameters[[currentScenarioName]]<-FishToxTranslator:::TemplateToDataFrame(chosenLifeHistoryParameters)
#
# ## Add on spawning
#
# # Run Spawning Algorithm
# dailySpawningProb<-GenerateSpawningProbs(repro_start=parameters[[currentScenarioName]]$repro_start[1],
#                                          repro_end=parameters[[currentScenarioName]]$repro_end[1],
#                                          spawns_max_season=parameters[[currentScenarioName]]$spawns_max_season[1],
#                                          spawn_int=parameters[[currentScenarioName]]$spawn_int[1])
#
# # Display plot upon algorithm completion
# plot(dailySpawningProb,main="Daily Spawning Probability",xlab="Ordinal Date",ylab="Spawning Probability")
#
# # Add spawning algorithm output to parameter data.frame
# parameters[[currentScenarioName]]<-cbind(parameters[[currentScenarioName]],p_spawn=dailySpawningProb)
#
# View(parameters)
#
# #### Create a second baseline for a different species, based on an uploaded .csv species template file
# ## In this case, it will be bluegill parameters
# currentScenarioName<-"Baseline 2" # take input
# scenarioNames<-cbind(scenarioNames,currentScenarioName) # append new scenario name to list
#
# # Submit scenario description as character string likely as a textAreaInput
# currentScenarioDescription<-"Baseline 2 for testing"
# scenarioDescriptions[[currentScenarioName]]<-currentScenarioDescription
#
# #Upload parameters
# #testing for new species
# newLifeHistory<-read.csv("lifeHistoryTemplate_2024-12-17_Bluegill.csv")
# parameters[[currentScenarioName]]<-FishToxTranslator:::TemplateToDataFrame(newLifeHistory)
#
# # GUI: Run Spawning Algorithm
# dailySpawningProb<-GenerateSpawningProbs(repro_start=parameters[[currentScenarioName]]$repro_start[1],
#                                          repro_end=parameters[[currentScenarioName]]$repro_end[1],
#                                          spawns_max_season=parameters[[currentScenarioName]]$spawns_max_season[1],
#                                          spawn_int=parameters[[currentScenarioName]]$spawn_int[1])
#
# # Display plot upon algorithm completion
# plot(dailySpawningProb,main="Daily Spawning Probability",xlab="Ordinal Date",ylab="Spawning Probability")
#
# # Add spawning algorithm output to parameter data.frame
# parameters[[currentScenarioName]]<-cbind(parameters[[currentScenarioName]],p_spawn=dailySpawningProb)
#
#
# ## Add on spawning
#
# # Run Spawning Algorithm
# dailySpawningProb<-GenerateSpawningProbs(repro_start=parameters[[currentScenarioName]]$repro_start[1],
#                                          repro_end=parameters[[currentScenarioName]]$repro_end[1],
#                                          spawns_max_season=parameters[[currentScenarioName]]$spawns_max_season[1],
#                                          spawn_int=parameters[[currentScenarioName]]$spawn_int[1])
#
# # Display plot upon algorithm completion
# plot(dailySpawningProb,main="Daily Spawning Probability",xlab="Ordinal Date",ylab="Spawning Probability")
#
# # Add spawning algorithm output to parameter data.frame
# parameters[[currentScenarioName]]<-cbind(parameters[[currentScenarioName]],p_spawn=dailySpawningProb)
#
# View(parameters)
#
# #### Choose functions to modify
# PlotSurvival<- function (pars,date,sizesToPlot=100,ForProfile=T,species=NA) {
#   if(ForProfile){
#     #Create species specific parameter list, sPars
#     speciesIn<-species #define species (this will normally be passed into function)
#     species_data_name<-subset(FishToxTranslator::species_library, common_name==speciesIn)$parameter_data #gather species parameters from parameters_master
#     species_sci_name<-subset(FishToxTranslator::species_library, common_name==speciesIn)$scientific_name #gather species sci name from parameters_master
#     species_data<-get(species_library$parameter_data)
#     sPars<-as.data.frame(t(species_data$value))
#     names(sPars)<-t(species_data$id)
#
#     sizes<-seq(from=sPars$z_hatch,to=sPars$z_inf,length.out=sizesToPlot)
#     surv<-Survival(sizes,sPars,date=1)
#     plot(sizes,surv,col="black",pch=18,xlab="Size (mm)",ylab="Survival probability",main=paste("Daily survival probability \n",species," (", species_sci_name,")",sep=""))
#
#     points(sizes,surv,col="black",pch=18,)
#
#   }
#   else{
#
#   if(missing(date)){return(print("Please provide a date"))}
#   natecols<-colorRampPalette(c("purple","steelblue","lightgreen","orange"))
#   if(is.data.frame(pars)){
#     sizes<-seq(from=pars$z_hatch[date],to=pars$z_inf[date],length.out=sizesToPlot)
#     surv<-Survival(sizes,pars,date)
#     plot(sizes,surv,col="salmon",pch=18,xlab="Size (mm)",ylab="Survival probability",main=paste("Daily survival probability - Ordinal date: ",date,sep=""))
#
#     points(sizes,surv,col="salmon",pch=18,)}
#   else{nParSets<-length(pars)
#   survs<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#   sizes<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#   for(i in 1:nParSets){
#     sizes[i,]<-seq(from=pars[[i]]$z_hatch[date],to=pars[[i]]$z_inf[date],length.out=sizesToPlot)
#     survs[i,]<-Survival(sizes[i,],pars[[i]],date=date)}
#
#   plot(sizes[i,],survs[1,],xlim=c(min(sizes),max(sizes)),ylim=c(min(survs),max(survs)),col=natecols(nParSets)[1],pch="",xlab="Size (mm)",ylab="Survival probability",main=paste("Daily survival probability - Ordinal date: ",date,sep=""))
#
#   legend("bottomright", cex=1, legend = names(pars), xpd = TRUE,
#          horiz = FALSE, col = natecols(nParSets), pch=seq(from=15,to=(15+nParSets)), bty = "n")
#   for(i in 1:nParSets){
#     points(sizes[i,],survs[i,],col=natecols(nParSets)[i],pch=18)}
#   }
#   for(i in 1:nParSets){
#     abline(v=pars[[i]]$z_inf[date],col=natecols(nParSets)[i])
#     axis(1, at = pars[[i]]$z_inf[date],
#          labels = F,col=natecols(nParSets)[i])
#     mtext("Max size", at=pars[[i]]$z_inf[date],col=natecols(nParSets)[i])
#   }
#   }
# }
#
# #### Test functions using parameters
# PlotSurvival(ForProfile=T,species="Fathead Minnow")
#
# #test if ordering of parameters is changed
# pars2<-list()
# pars2[["base1"]]<-parameters[["Baseline 2"]]
# pars2[["base2"]]<-parameters[["Baseline 1"]]
# pars2
#
# PlotSurvival(pars2,date=1)
# ### The above seems to be functioning properly.
#
# #### Plot growth function modifications
# PlotGrowth <- function (pars,date,sizesToPlot=100,bt=0,plotSDevs=T,ForProfile=F,species=NA) {
#   natecols<-colorRampPalette(c("purple","steelblue","lightgreen","orange"))
#   ##Profile version of plotting growth
#   if(ForProfile){ #creates the profile version of the growth plots, otherwise creates interactive GUI version
#     ###
#     #Create species specific parameter list, sPars
#     speciesIn<-species #define species (this will normally be passed into function)
#     species_data_name<-subset(FishToxTranslator::species_library, common_name==speciesIn)$parameter_data #gather species parameters from parameters_master
#     species_sci_name<-subset(FishToxTranslator::species_library, common_name==speciesIn)$scientific_name #gather species sci name from parameters_master
#     species_data<-get(species_library$parameter_data)
#     sPars<-as.data.frame(t(species_data$value))
#     names(sPars)<-t(species_data$id)
#
#     sizes<-seq(from=sPars$z_hatch,to=sPars$z_inf,length.out=sizesToPlot)
#     avg<-Growth(sizes,sizes,bt,sPars,date=1,muSDOut=T)[,1]-sizes
#     sdev<-Growth(sizes,sizes,bt,sPars,date=1,muSDOut=T)[,2]
#     plot(sizes, avg,
#          ylim=range(c(avg-sdev, avg+sdev)),
#          pch=19, xlab="Size (mm)", ylab=ifelse(plotSDevs,"Mean growth (mm) +/- SD","Mean growth (mm)"),
#          main=paste("Mean daily growth increments \n",species," (", species_sci_name,")",sep=""),
#          axes=T,col="black")
#
#     if(!min(sdev)>0){
#       points(sizes, avg,
#              ylim=range(c(avg-sdev, avg+sdev)),
#              pch=19,col="black")}
#     else{
#       if(plotSDevs==T){arrows(sizes, avg-sdev, sizes, avg+sdev, length=0.05, angle=90, code=3,col="black")}
#       points(sizes, avg,ylim=range(c(avg-sdev, avg+sdev)),pch=19,col="black")}
#   }
#   ###THIS IS WHERE THE OLD PLOTGROWTH FUNCTION BEGAN###
#   else{
#     if(missing(date)){return(print("Please provide a date"))}
#     if(is.data.frame(pars)){
#       sizes<-seq(from=pars$z_hatch[date],to=pars$z_inf[date],length.out=sizesToPlot)
#       avg<-Growth(sizes,sizes,bt,pars,date=date,muSDOut=T)[,1]-sizes
#       sdev<-Growth(sizes,sizes,bt,pars,date=date,muSDOut=T)[,2]
#       plot(sizes, avg,
#            ylim=range(c(avg-sdev, avg+sdev)),
#            pch=19, xlab="Size (mm)", ylab=ifelse(plotSDevs,"Mean growth (mm) +/- SD","Mean growth (mm)"),
#            main=paste("Daily growth increments - Ordinal date: ",date,sep=""),
#            axes=T,col="lightblue")
#
#       if(!min(sdev)>0){
#         points(sizes, avg,
#                ylim=range(c(avg-sdev, avg+sdev)),
#                pch=19,col="steelblue")}
#       else{
#         if(plotSDevs==T){arrows(sizes, avg-sdev, sizes, avg+sdev, length=0.05, angle=90, code=3,col="lightblue")}
#         points(sizes, avg,ylim=range(c(avg-sdev, avg+sdev)),pch=19,col="steelblue")}}
#     else{nParSets<-length(pars)
#     avgs<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#     sdevs<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#     allsizes<-matrix(NA,nrow=nParSets,ncol=sizesToPlot) #created to store and capture maximum and minimum sizes being plotted to set proper xlimits
#     sizes<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#     for(i in 1:nParSets){
#       allsizes[i,]<-seq(from=pars[[i]]$z_hatch[date],to=pars[[i]]$z_inf[date],length.out=sizesToPlot) #storing sizes to be recalled later for xlimits for plotting
#       sizes[i,]<-seq(from=pars[[i]]$z_hatch[date],to=pars[[i]]$z_inf[date],length.out=sizesToPlot)
#       avgs[i,]<-Growth(sizes[i,],sizes[i,],bt,pars[[i]],date=date,muSDOut=T)[,1]-sizes[i,]
#       sdevs[i,]<-Growth(sizes[i,],sizes[i,],bt,pars[[i]],date=date,muSDOut=T)[,2] }
#
#     plot(x=seq(from=min(allsizes),to=max(allsizes),length.out=sizesToPlot), y=avgs[1,],xlim=c(min(allsizes),max(allsizes)),ylim=c(min(avgs)-max(sdevs),max(avgs)+max(sdevs)),col=natecols(nParSets)[1],pch="", xlab="Size (mm)", ylab=ifelse(plotSDevs,"Mean growth (mm) +/- SD","Mean growth (mm)"),
#          main=paste("Daily growth increments - Ordinal date: ",date,sep="")) #Plot command modified to attempt to allow for rescaling for species with different z_hatch and z_inf values
#
#     for(i in 1:nParSets){
#       if(!min(sdevs[i,])>0){
#         points(x=sizes[i,],y=avgs[i,],pch=14+i,col=natecols(nParSets)[i])}
#       else{
#         if(plotSDevs==T){arrows(sizes[i,], avgs[i,]-sdevs[i,], sizes[i,], avgs[i,]+sdevs[i,], length=0.05, angle=90, code=3,col=natecols(nParSets)[i])}
#         points(x=sizes[i,],y=avgs[i,],pch=14+i,col=natecols(nParSets)[i])}}
#     }
#     for(i in 1:nParSets){
#       abline(v=pars[[i]]$z_inf[date],col=natecols(nParSets)[i])
#       axis(1, at = pars[[i]]$z_inf[date],
#            labels = F,col=natecols(nParSets)[i])
#       mtext("Max size", at=pars[[i]]$z_inf[date],col=natecols(nParSets)[i])
#     }
#     legend("topright",inset=.01, cex=1, legend = names(pars), xpd = TRUE,
#            horiz = FALSE, col = natecols(nParSets), pch=seq(from=15,to=(15+nParSets)), bty = "n")
#   }
# }
#
# PlotGrowth(pars2,date=1)
#
# #### Now for reproduction
#
# PlotReproduction<- function (pars,date,reprolines=F,sizesToPlot=100,ForProfile=F,species=NA) {
#   if(ForProfile){
#     date=1
#     #Create species specific parameter list, sPars
#     speciesIn<-species #define species (this will normally be passed into function)
#     species_data_name<-subset(FishToxTranslator::species_library, common_name==speciesIn)$parameter_data #gather species parameters from parameters_master
#     species_sci_name<-subset(FishToxTranslator::species_library, common_name==speciesIn)$scientific_name #gather species sci name from parameters_master
#     species_data<-get(species_library$parameter_data)
#     sPars<-as.data.frame(t(species_data$value))
#     names(sPars)<-t(species_data$id)
#
#     sizes<-seq(from=sPars$z_hatch,to=sPars$z_inf,length.out=sizesToPlot)
#     repro<-sPars$sex_ratio[date]*Fecundity(sizes,sPars,date)*Survival(sPars$z_hatch[date],sPars,date)
#     plot(sizes,repro,col="black",pch=18,xlab="Size (mm)",ylab="Female hatchlings/female/per day ",main=paste("Daily maximum reproductive output \n",species," (", species_sci_name,")",sep=""))
#
#     points(sizes,repro,col="black",pch=18)}
#   else{
#
#     if(missing(date)){return(print("Please provide a date"))}
#   natecols<-colorRampPalette(c("purple","steelblue","lightgreen","orange"))
#   if(is.data.frame(pars)){
#     sizes<-seq(from=pars$z_hatch[date],to=pars$z_inf[date],length.out=sizesToPlot)
#     repro<-pars$sex_ratio[date]*Spawning(sizes,pars,date)*Fecundity(sizes,pars,date)*Survival(pars$z_hatch[date],pars,date)
#     plot(sizes,repro,col="salmon",pch=18,xlab="Size (mm)",ylab="Avg female hatchlings/female/per day ",main=paste("Daily reproductive output \n Ordinal date: ",date,sep=""))
#
#     points(sizes,repro,col="salmon",pch=18)}
#   else{nParSets<-length(pars)
#   sizes<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#   repros<-matrix(NA,nrow=nParSets,ncol=sizesToPlot)
#   for(i in 1:nParSets){
#     sizes[i,]<-seq(from=pars[[i]]$z_hatch[date],to=pars[[i]]$z_inf[date],length.out=sizesToPlot)
#     repros[i,]<-pars[[i]]$sex_ratio[date]*Spawning(sizes[i,],pars[[i]],date)*Fecundity(sizes[i,],pars[[i]],date)*Survival(pars[[i]]$z_hatch[date],pars[[i]],date)}
#
#   plot(x=seq(from=min(sizes),to=max(sizes),length.out=sizesToPlot),repros[1,],ylim=c(min(repros),max(repros)),col=natecols(nParSets)[1],pch="",xlab="Size (mm)",ylab="Avg female hatchlings/female/per day ",main=paste("Daily reproductive output \n Ordinal date: ",date,sep=""))
#
#   legend("topleft", cex=1, legend = names(pars), xpd = TRUE,
#          horiz = FALSE, col = natecols(nParSets), pch=seq(from=15,to=(15+nParSets)), bty = "n")
#   for(i in 1:nParSets){
#     points(sizes[i,],repros[i,],col=natecols(nParSets)[i],pch=18)}
#   for(i in 1:nParSets){
#     abline(v=pars[[i]]$z_inf[date],col=natecols(nParSets)[i])
#     axis(1, at = pars[[i]]$z_inf[date],
#          labels = F,col=natecols(nParSets)[i])
#     mtext("Max size", at=pars[[i]]$z_inf[date],col=natecols(nParSets)[i])}
#   for(i in 1:nParSets){
#     if(reprolines){abline(v=pars[[i]]$z_repro[date],col=natecols(nParSets)[i],lty="dotted")
#     axis(1, at = pars[[i]]$z_repro[date],
#          labels = F,col=natecols(nParSets)[i])
#     mtext("Repro size",side=1, at=pars[[i]]$z_repro[date],col=natecols(nParSets)[i])}
#   }
#   }
#   }
# }
#
# PlotReproduction(ForProfile=T,species="Fathead Minnow")
